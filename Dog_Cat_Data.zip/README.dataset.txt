# SampleTest > 2024-11-27 12:43pm
https://universe.roboflow.com/pytorchyololabelingworkbusanit/sampletest-lllqo

Provided by a Roboflow user
License: CC BY 4.0

